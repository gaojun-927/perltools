function y=rms(x)
y=sqrt(sum(x.*x)/length(x));
end